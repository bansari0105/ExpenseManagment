// backend/controllers/expenseController.js
const Expense = require('../models/Expense');
const Company = require('../models/Company');
const User = require('../models/User');
const workflowEngine = require('../services/workflowEngine');
const currencyService = require('../services/currencyService');
const notificationService = require('../services/notificationService');

/**
 * @desc Get all expenses for the current user (Employee)
 * @route GET /api/expenses/my
 * @access Private/Employee
 */
exports.getMyExpenses = async (req, res) => {
    try {
        const expenses = await Expense.find({ requestOwner: req.user.id })
            .sort({ expenseDate: -1 });

        res.json(expenses);
    } catch (error) {
        console.error('Error fetching user expenses:', error);
        res.status(500).json({ message: 'Server error fetching expenses.' });
    }
};

/**
 * @desc Submit a new expense claim
 * @route POST /api/expenses
 * @access Private/Employee
 */
exports.createExpense = async (req, res) => {
    try {
        const {
            description,
            category,
            expenseDate,
            paidBy, // Mock field for now
            totalAmount,
            currency,
            remarks,
            // receiptData // For OCR mock
        } = req.body;

        const requestOwner = req.user.id;
        const companyId = req.user.company;

        // --- 1. Currency Conversion ---
        const companyInfo = await Company.findById(companyId);
        if (!companyInfo) return res.status(404).json({ message: 'Company not found.' });
        
        const companyBaseCurrency = companyInfo.baseCurrency;
        const convertedAmount = await currencyService.convert(totalAmount, currency, companyBaseCurrency);
        
        // --- 2. Workflow Initialization ---
        const initialApprovers = await workflowEngine.getInitialApprovers({
            company: companyId,
            requestOwner,
            totalAmount: convertedAmount,
        });

        if (initialApprovers.length === 0) {
             return res.status(400).json({ 
                message: 'No approval workflow found or initial approver could not be determined.' 
            });
        }

        // --- 3. Save Expense ---
        const newExpense = new Expense({
            company: companyId,
            requestOwner,
            description,
            category,
            expenseDate,
            paidBy,
            totalAmount, // Original amount
            currency, // Original currency
            convertedAmount, // Converted amount
            companyBaseCurrency: companyBaseCurrency,
            remarks,
            status: 'Waiting approval',
            currentApprovers: initialApprovers,
        });

        await newExpense.save();

        // --- 4. Notification ---
        const owner = await User.findById(requestOwner);
        notificationService.notifyApprovers(initialApprovers, newExpense._id, owner.name);

        res.status(201).json({
            message: 'Expense submitted for approval.',
            expense: newExpense,
        });
    } catch (error) {
        console.error('Error creating expense:', error);
        res.status(500).json({ error: error.message });
    }
};
