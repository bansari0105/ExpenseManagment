// backend/controllers/approvalController.js
const Expense = require('../models/Expense');
const workflowEngine = require('../services/workflowEngine');
const notificationService = require('../services/notificationService');

/**
 * @desc Get expenses waiting for the current Manager/Admin's approval
 * @route GET /api/approvals/pending
 * @access Private/Manager, Admin
 */
exports.getPendingApprovals = async (req, res) => {
    try {
        const pendingExpenses = await Expense.find({
            // Find expenses where the current user is listed as a current approver
            currentApprovers: req.user.id,
            status: 'Waiting approval'
        })
        .populate('requestOwner', 'name email')
        .sort({ createdAt: 1 });

        res.json(pendingExpenses);
    } catch (error) {
        console.error('Error fetching pending approvals:', error);
        res.status(500).json({ message: 'Server error fetching pending approvals.' });
    }
};


/**
 * @desc Approve an expense
 * @route POST /api/approvals/approve/:expenseId
 * @access Private/Manager, Admin
 */
exports.approveExpense = async (req, res) => {
    try {
        const { expenseId } = req.params;
        const approverId = req.user.id;
        const { comments } = req.body;

        const expense = await Expense.findById(expenseId);
        if (!expense) {
            return res.status(404).json({ message: 'Expense not found.' });
        }

        // Check if the current user is an authorized approver for this expense
        if (!expense.currentApprovers.map(id => id.toString()).includes(approverId)) {
            return res.status(403).json({ message: 'Not authorized to approve this expense.' });
        }
        
        // Call the workflow engine to process the approval
        const { newStatus, nextApprovers } = await workflowEngine.processApproval(expenseId, approverId, comments);

        // Notify the next approver(s) if applicable
        if (newStatus === 'Waiting approval' && nextApprovers.length > 0) {
            notificationService.notifyApprovers(nextApprovers, expenseId, expense.requestOwner.name);
        }

        res.status(200).json({
            message: newStatus === 'Approved' ? 'Expense fully approved.' : 'Expense approved, moving to next step.',
            status: newStatus,
            nextApprovers: nextApprovers.map(a => a.toString()),
        });
    } catch (error) {
        console.error('Error approving expense:', error);
        res.status(500).json({ error: error.message });
    }
};

/**
 * @desc Reject an expense
 * @route POST /api/approvals/reject/:expenseId
 * @access Private/Manager, Admin
 */
exports.rejectExpense = async (req, res) => {
    try {
        const { expenseId } = req.params;
        const approverId = req.user.id;
        const { comments } = req.body; // Capture rejection reason

        const expense = await Expense.findById(expenseId);
        if (!expense) {
            return res.status(404).json({ message: 'Expense not found.' });
        }

        if (!expense.currentApprovers.map(id => id.toString()).includes(approverId)) {
            return res.status(403).json({ message: 'Not authorized to reject this expense.' });
        }

        // Call the workflow engine to process the rejection
        const { newStatus } = await workflowEngine.processRejection(expenseId, approverId, comments);

        res.status(200).json({
            message: 'Expense rejected.',
            status: newStatus,
        });
    } catch (error) {
        console.error('Error rejecting expense:', error);
        res.status(500).json({ error: error.message });
    }
};
