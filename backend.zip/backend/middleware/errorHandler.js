// backend/middleware/errorHandler.js

/**
 * Custom error handler middleware for Express.
 * This should be the last piece of middleware loaded.
 */
const errorHandler = (err, req, res, next) => {
    // Determine status code based on error type, default to 500
    const statusCode = res.statusCode === 200 ? 500 : res.statusCode;
    
    // Log the error for server-side inspection
    console.error(`Error ${statusCode}: ${err.message}`);
    // console.error(err.stack); // Optionally log the stack trace

    res.status(statusCode).json({
        message: err.message,
        // In production, avoid sending the stack trace
        stack: process.env.NODE_ENV === 'production' ? null : err.stack,
    });
};

module.exports = errorHandler;
