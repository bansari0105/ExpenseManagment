import mongoose from "mongoose";

const workflowRuleSchema = new mongoose.Schema({
  company: { type: mongoose.Schema.Types.ObjectId, ref: "Company", required: true },
  steps: [
    {
      approverRole: { type: String, enum: ["Manager", "Finance", "Director", "Admin"] },
      sequence: { type: Number }
    }
  ],
  conditionalRules: {
    percentage: { type: Number, default: 0 },
    specificApprover: { type: mongoose.Schema.Types.ObjectId, ref: "User", default: null }
  }
}, { timestamps: true });

export default mongoose.model("WorkflowRule", workflowRuleSchema);
