const mongoose = require("mongoose");

const expenseSchema = new mongoose.Schema({
  employee: { type: mongoose.Schema.Types.ObjectId, ref: "User", required: true },
  amount: { type: Number, required: true },
  currency: { type: String, default: "USD" },
  category: { type: String, required: true },
  description: { type: String },
  date: { type: Date, required: true },
  status: { type: String, enum: ["Pending","Approved","Rejected"], default: "Pending" },
  approvals: [{ approver: { type: mongoose.Schema.Types.ObjectId, ref: "User" }, status: String, comment: String }]
}, { timestamps: true });

module.exports = mongoose.model("Expense", expenseSchema);
