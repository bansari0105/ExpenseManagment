const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  country: { type: String },
  currency: { type: String }
}, { timestamps: true });

// Export the model correctly
module.exports = mongoose.model('User', userSchema);
