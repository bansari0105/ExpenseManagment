const axios = require('axios');

const getRates = async (base) => {
  const url = `${process.env.EXCHANGE_API_BASE}/${base}`;
  const res = await axios.get(url);
  return res.data; // { base, date, rates: { USD:1, INR:... } }
};

const convert = async (amount, from, to) => {
  if (from === to) return amount;
  const data = await getRates(from);
  const rate = data.rates[to];
  if (!rate) throw new Error('Rate not available');
  return amount * rate;
};

module.exports = { getRates, convert };
