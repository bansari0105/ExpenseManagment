const Expense = require('../models/Expense');
const WorkflowRule = require('../models/WorkflowRule');
const User = require('../models/User');

/**
 * Initialize approval steps from company workflow or ad-hoc approvers.
 * For simple case: pass approver user IDs in sequence.
 */
const initializeApprovalSteps = async (expense, approverIds=[]) => {
  expense.approvalSteps = approverIds.map(id => ({ approver: id, status: 'Pending' }));
  await expense.save();
  return expense;
};

/**
 * Process an approval action and decide next status using the configured rule.
 * action: { expenseId, approverId, action: 'Approve'|'Reject', comments }
 */
const processApproval = async ({ expenseId, approverId, action, comments }) => {
  const expense = await Expense.findById(expenseId).populate('approvalSteps.approver approvalRule.specificApprover');
  if (!expense) throw new Error('Expense not found');

  // find step
  const step = expense.approvalSteps.find(s => String(s.approver._id) === String(approverId));
  if (!step || step.status !== 'Pending') throw new Error('No pending approval step for this user');

  step.status = action === 'Approve' ? 'Approved' : 'Rejected';
  step.comments = comments;
  step.actedAt = new Date();

  // If rejected -> final
  if (action === 'Reject') {
    expense.status = 'Rejected';
    await expense.save();
    return expense;
  }

  // Now evaluate approval rules
  // SPECIFIC -> if specific approver has approved => auto-approved
  if (expense.approvalRule && expense.approvalRule.type === 'SPECIFIC') {
    if (expense.approvalRule.specificApprover && String(expense.approvalRule.specificApprover._id) === String(approverId)) {
      expense.status = 'Approved';
      await expense.save();
      return expense;
    }
  }

  // PERCENTAGE: compute percentage of approvers who approved
  const total = expense.approvalSteps.length;
  const approvedCount = expense.approvalSteps.filter(s => s.status === 'Approved').length;
  const percent = (approvedCount / total) * 100;
  const required = expense.approvalRule ? expense.approvalRule.percentage : 100;

  if (percent >= required) {
    expense.status = 'Approved';
    await expense.save();
    return expense;
  }

  // If sequential workflow, move to next pending approver (we can notify them)
  // If no pending approvers left, final status decision by percent (already handled)
  await expense.save();
  return expense;
};

module.exports = { initializeApprovalSteps, processApproval };
