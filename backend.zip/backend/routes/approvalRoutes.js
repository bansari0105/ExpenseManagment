// backend/routes/approvalRoutes.js
const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const approvalController = require('../controllers/approvalController');

const router = express.Router();

// Apply authentication to all routes
router.use(protect);

// Manager/Admin routes
// @route GET /api/approvals/pending - Get expenses waiting for current user's approval
router.get('/pending', authorize(['manager', 'admin']), approvalController.getPendingApprovals);

// @route POST /api/approvals/approve/:expenseId - Approve an expense
router.post('/approve/:expenseId', authorize(['manager', 'admin']), approvalController.approveExpense);

// @route POST /api/approvals/reject/:expenseId - Reject an expense
router.post('/reject/:expenseId', authorize(['manager', 'admin']), approvalController.rejectExpense);

module.exports = router;
