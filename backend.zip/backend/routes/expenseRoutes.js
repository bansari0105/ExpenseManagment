// backend/routes/expenseRoutes.js
const express = require('express');
const { protect } = require('../middleware/authMiddleware');
const { authorize } = require('../middleware/roleMiddleware');
const expenseController = require('../controllers/expenseController');

const router = express.Router();

// Apply authentication to all routes
router.use(protect);

// Employee routes
// @route GET /api/expenses/my - Get all expenses submitted by the current user
router.get('/my', authorize(['employee', 'manager', 'admin']), expenseController.getMyExpenses);
// @route POST /api/expenses - Submit a new expense
router.post('/', authorize(['employee', 'manager', 'admin']), expenseController.createExpense);

// Admin/Manager routes for viewing team/all expenses can be added here:
// router.get('/team', authorize(['manager']), expenseController.getTeamExpenses);
// router.get('/all', authorize(['admin']), expenseController.getAllCompanyExpenses);

module.exports = router;
